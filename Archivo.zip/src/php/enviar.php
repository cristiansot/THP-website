<?php 
	$nombre = $_POST['nombre'];
	$email = $_POST['email'];
	$asunto = 'Formulario Rellenado';
	$mensaje = "Nombre: ".$nombre."
	Email: $email
	Mensaje:".$_POST['mensaje'];

	if(mail('csoto@gssd.cl', $asunto, $mensaje)){
		echo "Su correo ha sido enviado con éxito";
	} else {
		echo "Error al enviar su correo, inténtelo más tarde";
	}
	window.location.replace("https://www.thp.cl");

 ?>